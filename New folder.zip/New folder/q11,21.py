from sklearn.datasets import load_iris
from sklearn.preprocessing import MinMaxScaler

iris=load_iris()
print(iris)
x=iris.data
y=iris.target
scaler=MinMaxScaler()

rescale=scaler.fit_transform(x)
print(rescale)
