import pandas as pd

data=pd.read_csv("StudentsPerformance.csv")

print("shape of dataset is:")
shape=data.shape
print(shape)

print("top 5 rows of datase :")
print(data.head())

print("random rows from dataset")
print(data.sample(5))

print("number of columns are ")
print(data.columns)

print("column names ")
print(list(data.columns))


