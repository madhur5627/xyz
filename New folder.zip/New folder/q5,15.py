import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder

data=pd.read_csv('shows.csv')
le=LabelEncoder();

data['Nationality']=le.fit_transform(data['Nationality'])
data['Go']=le.fit_transform(data['Go'])

x=data[['Age','Experience','Rank','Nationality']]
y=data['Go']


classifier=DecisionTreeClassifier()
classifier.fit(x,y)

prediction=classifier.predict([[40,10,7,2],[50,13,7,0]])
print(prediction)
if(prediction[0]==1):
	print("SUCCESSFUL")
else:
	print("UNSUCCESSFUL")



