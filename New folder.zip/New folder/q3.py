import numpy as np

x=np.array([0,1,2,3,4,5,6,7,8,9,11,13])
y=np.array([1,3,2,5,7,8,8,9,10,12,16,18])
n=len(x)
sum_x=np.sum(x)
sum_y=np.sum(y)
sum_xy=np.sum(x*y)
sum_x_square=np.sum(x**2)

b1=(n*sum_xy-sum_x*sum_y)/(n*sum_x_square-sum_x**2)
b0=(sum_y-b1*sum_x)/n

print("coefficient b0 is ")
print(b0)
print("coefficient b1 is ")
print(b1)

