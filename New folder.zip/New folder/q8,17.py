import pandas as pd
data=pd.read_csv('DataPreprocessing.csv')
print("original data\n")
print(data)
print("\nnull valu data :\n")
print(data[data.isnull().any(axis=1)])
new_data=data.dropna()
print("\ndata after dropping null values\n")
print(new_data)
