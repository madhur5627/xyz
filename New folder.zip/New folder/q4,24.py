import pandas as pd
from sklearn.naive_bayes import CategoricalNB
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

data=pd.read_csv('forecast.csv')
le=LabelEncoder();

print(data)
data['weather']=le.fit_transform(data['weather'])
data['temp']=le.fit_transform(data['temp'])

x=data[['weather','temp']]
y=data['play']

print(x)
print(y)

model=CategoricalNB()
model.fit(x,y)

prediction=model.predict([[0,2],[2,1]])
print(prediction)
if(prediction[0]=='yes'):
	print("play the sports")
else:
	print("doesn't play the sports")	

