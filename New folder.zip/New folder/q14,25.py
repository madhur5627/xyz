import pandas as pd
from mlxtend.frequent_patterns import apriori,association_rules
from mlxtend.preprocessing import TransactionEncoder

df=pd.read_csv("Groceries_dataset.csv")

transactions=df.groupby(('member__number')['itemDescription'].apply(lambda x:x.tolist()).tolist()
te=TransactionEncoder()
te_ary=te.fit(transactions).transform(transactions)

df_trans=pd.DataFrame(te_ary,columns=te.columns)

frequent_itemset=apriori(df_trans,min_support=0.01,use_colnames=true)
print("frequent itemsets are :")
print(frequent_itemset)

rules=association_rules(frequent_itemset,metric="confidence",min_threshold=0.5)
simplified_rules=rules[['antecedent','consequent','support','confidence','lift']]
print("association rules are :")
print(simplified_rules)
